# saathi_app/app/main_app.py
import streamlit as st
#from streamlit_webrtc import webrtc_streamer, AudioProcessorBase, WebRtcMode
import logging
import os
import sys
from dotenv import load_dotenv
import nltk
import pandas as pd
from datetime import datetime, timedelta
from collections import defaultdict
import altair as alt
#import av


# --- Basic Setup ---
load_dotenv()

# KEPT: Your existing logging configuration
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('saathi_agentic.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def ensure_nltk_data():
    """
    Ensures all required NLTK data packages are available.
    nltk.download() is idempotent and will not re-download if the package is up-to-date.
    This is simpler and more robust than checking for the path first.
    """
    logger.info("Verifying NLTK data packages (punkt, wordnet, averaged_perceptron_tagger)...")
    try:
        packages = ['punkt', 'wordnet', 'averaged_perceptron_tagger']
        for pkg_id in packages:
            nltk.download(pkg_id, quiet=True) # Use quiet=True to hide "up-to-date" messages
        logger.info("NLTK data verification complete.")
    except Exception as e:
        logger.error(f"Failed to verify/download NLTK packages: {e}")
        st.error("Could not initialize required NLTK data. The app may not function correctly.")

# Custom path setup for reliable imports
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
sys.path.insert(0, project_root)

# This ensures the check only runs once at the very beginning of a session.
if 'nltk_data_verified' not in st.session_state:
    ensure_nltk_data()
    st.session_state.nltk_data_verified = True

#ensure_nltk_data()

# KEPT: All your required agent and module imports
from models.llm_setup import initialize_llm, initialize_embedding_model
from models.graphrag_engine import initialize_neo4j_graph, HybridRetriever
from core.memory_manager import EnhancedConversationMemory
from core.orchestrator_agent import OrchestratorAgent
from core.retriever_agent import RetrieverAgent
from core.clinical_assessment_agent import ClinicalAssessmentAgent
from core.recommendation_agent import RecommendationAgent
from config import INDIAN_CRISIS_RESOURCES, AssessmentState
from core.cbt_agent import CBTAgent
from core.user_profile_manager import UserProfileManager, CbtProgressTracker
from core.cbt_content_library import CBT_PACKAGES
#from core.voice_agent import VoiceAgent # Import the new agent

st.set_page_config(page_title="Saathi AI", page_icon="🧠", layout="wide")


# --- System Initialization ---
@st.cache_resource
def get_neo4j_graph():
    """Creates and caches a single Neo4j graph connection for the session."""
    logger.info("Creating single Neo4j graph connection for session.")
    return initialize_neo4j_graph()

@st.cache_resource
def initialize_systems(_graph):
    """Initializes all backend agents using the provided graph connection."""
    try:
        llm = initialize_llm()
        embedding_model = initialize_embedding_model()
                
        user_profile_manager = UserProfileManager()
        cbt_progress_tracker = CbtProgressTracker(_graph)
        cbt_agent = CBTAgent(llm, cbt_progress_tracker, user_profile_manager)
        #voice_agent = VoiceAgent() # Initialize the new agent

        hybrid_retriever = HybridRetriever(_graph, embedding_model)
        retriever_agent = RetrieverAgent(hybrid_retriever)
        assessment_agent = ClinicalAssessmentAgent()
        recommendation_agent = RecommendationAgent(_graph)
        
        orchestrator = OrchestratorAgent(
            llm=llm,
            retriever_agent=retriever_agent,
            assessment_agent=assessment_agent,
            rec_agent=recommendation_agent,
            cbt_agent=cbt_agent
        )
        return orchestrator, embedding_model, assessment_agent, cbt_agent, user_profile_manager, cbt_progress_tracker
    except Exception as e:
        st.error(f"Fatal Error during initialization: {e}")
        logging.error(f"Fatal Error during initialization: {e}", exc_info=True)
        return None, None, None, None, None, None, None

def main():
    st.title("🧠 Saathi - Your AI Mental Health Companion") # KEPT
    # KEPT: Your disclaimer markdown
    st.markdown("""
        <div style="background-color:#f0f2f6; padding:15px; border-radius:5px; border-left: 5px solid #ff4b4b;">
        <strong>⚠️ Disclaimer:</strong> I am an AI assistant and not a substitute for a human therapist or medical professional. 
        If you are in crisis, please contact emergency services or a crisis helpline immediately.
        </div>
    """, unsafe_allow_html=True)

    # ---  CONSENT GATE ---
    if 'consent_given' not in st.session_state:
        st.header("Your Privacy and Consent")
        st.write("Before we begin your journey with Saathi, please review how your data is handled. Your trust and privacy are our top priorities.")

        st.subheader("What Data We Collect")
        st.markdown("""
        * **Anonymous ID**: Your 'secret phrase' is used to identify your journey without knowing who you are.
        * **Assessment Results**: Your scores and severity from clinical screenings (e.g., PHQ-9, GAD-7).
        * **Your Story & CBT Responses**: The summary of your initial conversation and your answers to exercises within the therapy modules.
        """)

        st.subheader("Why We Collect It")
        st.markdown("""
        * To **personalize** your therapeutic journey and remember your progress between sessions.
        * To **track** your assessment scores over time so you can see your progress visually.
        * To **improve** our service and understand which features are most helpful for our users.
        """)
        
        st.subheader("Your Rights")
        st.markdown("""
        * You have the right to **export** and **delete** all of your data at any time from the "My Journey" panel.
        """)

        st.warning("Your specific data is always encrypted and will never be shared with third parties.")

        if st.button("I Understand and Consent to an Anonymous, Encrypted Record of My Journey"):
            st.session_state.consent_given = True
            st.rerun()
        return

    # --- User Identity Gate (Secret Phrase) ---
    if 'secret_phrase' not in st.session_state:
        st.header("Welcome Back or Get Started")
        st.write("To load or start your anonymous journey, please enter a unique Secret Phrase. If you are new, create one now and remember it for the future (e.g., 'happy-purple-tree-7').")
        
        phrase = st.text_input("Your Secret Phrase", type="password", key="secret_phrase_input")
        if st.button("Begin Session"):
            if phrase and len(phrase.split('-')) > 2 and len(phrase) > 10:
                st.session_state.secret_phrase = phrase
                st.session_state.user_id = phrase
                try:
                    with st.spinner("Setting up your secure session..."):
                        # We need a direct connection to Neo4j here to record consent
                        graph = get_neo4j_graph()
                        tracker = CbtProgressTracker(graph)
                        tracker.record_user_consent(st.session_state.user_id)
                    st.rerun()
                except Exception as e:
                    st.error("Could not connect to the database to record consent. Please try again.")
                    logger.error(f"Failed to initialize graph for consent recording: {e}")
            else:
                st.error("Please use a more secure phrase, like 'word1-word2-word3'.")
        return

    # --- MAIN APP LOGIC (USER IS LOGGED IN) ---
    user_id = st.session_state.user_id
    secret_phrase = st.session_state.secret_phrase
    
    # Get the single connection and pass it to the systems
    graph = get_neo4j_graph()
    orchestrator, embedding_model, assessment_agent, cbt_agent, user_profile_manager, cbt_progress_tracker = initialize_systems(graph)
    if not orchestrator:
        st.stop()

    # --- UI MODE SELECTION ---
    #st.sidebar.divider()
    #mode = st.sidebar.radio("Choose interaction mode:", ("✍️ Text Chat", "🎤 Voice Chat"), horizontal=True)
    
    # --- Profile Loading with Error Handling ---
    try:
        if 'profile' not in st.session_state:
             st.session_state.profile = user_profile_manager.load_profile(user_id, secret_phrase)
    except ValueError:
        st.error("Incorrect Secret Phrase. Please refresh and try again.")
        del st.session_state.secret_phrase
        return

    # --- Session Timeout Logic ---
    SESSION_TIMEOUT_MINUTES = 15
    if 'last_interaction' not in st.session_state:
        st.session_state.last_interaction = datetime.now()
    if datetime.now() - st.session_state.last_interaction > timedelta(minutes=SESSION_TIMEOUT_MINUTES):
        st.warning(f"Your session has expired due to inactivity. Please log in again.")
        for key in ['memory', 'messages', 'user_id', 'secret_phrase', 'profile']:
            if key in st.session_state:
                del st.session_state[key]
        st.rerun()

    # --- Session State Initialization ---
    if "memory" not in st.session_state:
        st.session_state.memory = EnhancedConversationMemory(embedding_model)

    if "messages" not in st.session_state:
        st.session_state.messages = []
        profile = st.session_state.profile

        # Case 1: Resume an in-progress CBT module.
        if profile.get("cbt_progress", {}).get("active_module_id"):
            st.session_state.memory.assessment_state = AssessmentState.IN_CBT_JOURNEY
            st.session_state.messages.append({"role": "assistant", "content": "👋 Welcome back! It looks like we were in the middle of a CBT session. Let's pick up where we left off."})
            next_step = cbt_agent.continue_cbt_journey(user_id, "", profile)
            st.session_state.messages.append({"role": "assistant", "content": next_step})
        
        # Case 2: Proactively offer next module to a returning user.
        elif profile.get("goals") and cbt_progress_tracker.get_completed_module_ids(user_id):
            with st.spinner("Preparing your next session..."):
                recommendation = cbt_agent.recommend_next_module(user_id, profile)
            if recommendation.get("module_id") == "ALL_COMPLETE":
                welcome_message = "👋 Welcome back! It looks like you've completed all the available CBT modules. You can continue our conversation by sharing how you're feeling today."
            elif recommendation.get("reason"):
                st.session_state.memory.assessment_state = AssessmentState.AWAITING_NEXT_MODULE_CONSENT
                st.session_state.memory.pending_module_id = recommendation['module_id']
                welcome_message = f"👋 Welcome back, {user_id}! {recommendation['reason']} Would you like to start this module now?"
                st.session_state.next_module_proposal = recommendation['module_id']
            else:
                st.session_state.memory.assessment_state = AssessmentState.INITIAL_SCREENING
                welcome_message = f"👋 Welcome back, {user_id}! It's great to see you again."
            st.session_state.messages.append({"role": "assistant", "content": welcome_message})
        
        # Case 3: Returning user with history but no completed modules.
        elif profile.get("assessment_history"):
            st.session_state.messages.append({"role": "assistant", "content": f"👋 Welcome back, {user_id}! It looks like we haven't started a CBT module yet. You can begin by sharing how you're feeling, or by saying 'start my first session'."})
        
        # Case 4: Truly new user.
        else:
            st.session_state.messages.append({"role": "assistant", "content": f"Welcome to Saathi, {user_id}! Let's start your journey."})
    
    # --- NEW: SCHEDULING GATE ---
    if 'memory' in st.session_state and st.session_state.memory.assessment_state == AssessmentState.SCHEDULING_SESSION:
        st.header("🗓️ Schedule Your Next Session")
        st.write("Choose a date and time that works for you. We'll remind you when you next log in.")

        next_module_id = "LI_M2" # In a real app, you'd have logic to select the next module
        
        col1, col2 = st.columns(2)
        with col1:
            d = st.date_input("Date", value="today")
        with col2:
            t = st.time_input("Time", value="now")

        if st.button("Confirm Schedule"):
            scheduled_time = datetime.combine(d, t)
            st.session_state.profile['scheduled_session'] = {
                "module_id": next_module_id,
                "time": scheduled_time.isoformat()
            }
            user_profile_manager.save_profile(user_id, secret_phrase, st.session_state.profile)
            
            st.session_state.memory.assessment_state = AssessmentState.INITIAL_SCREENING
            st.success(f"Great! Your next session is scheduled for {scheduled_time.strftime('%A, %B %d at %I:%M %p')}.")
            st.info("You can now close the app or ask another question.")
            # We don't rerun here, just show confirmation.
        return

    # --- NEW: REMINDER LOGIC ---
    if 'profile' in st.session_state and st.session_state.profile.get('scheduled_session'):
        scheduled_info = st.session_state.profile['scheduled_session']
        scheduled_time = datetime.fromisoformat(scheduled_info['time'])
        if datetime.now() > scheduled_time:
            st.info(f"👋 Welcome back! It looks like you have a CBT session scheduled for '{scheduled_info['module_id']}'. Are you ready to begin?")
            col1, col2 = st.columns(2)
            if col1.button("Yes, Let's Start"):
                # Logic to start the specific scheduled module...
                st.session_state.profile['scheduled_session'] = None # Clear the schedule
                user_profile_manager.save_profile(user_id, secret_phrase, st.session_state.profile)
                st.session_state.memory.assessment_state = AssessmentState.IN_CBT_JOURNEY
                # This would need more logic to start a *specific* module
                st.rerun()
            if col2.button("Not Right Now"):
                st.session_state.profile['scheduled_session'] = None # Clear the schedule
                user_profile_manager.save_profile(user_id, secret_phrase, st.session_state.profile)
                st.rerun()
    
    # --- NEW GOAL SETTING GATE---
    if 'memory' in st.session_state and st.session_state.memory.assessment_state == AssessmentState.GOAL_SETTING: 
        st.header("What are your goals for our CBT sessions? What would you like to achieve?")
        st.write("Setting a clear goal helps make the therapy more effective. Based on your recent assessment, here are some suggestions.")

        # Personalize suggestions based on the last assessment
        last_assessment = st.session_state.profile['assessment_history'][-1]

        # GENERATE GOAL_OPTIONS WITH A DYNAMIC CALL 
        with st.spinner("Generating personalized goals for you now..."):
            context_summary_text = cbt_progress_tracker.get_context_summary(user_id)
            goal_options = orchestrator.generate_goals(last_assessment, context_summary_text)        
        selected_goals = st.multiselect(
                "Choose your goals, or add your own custom goal below:",
                options=goal_options
        )

        custom_goal = st.text_input("Add a custom goal (optional):")

        if st.button("Save Goals and Start First Session"):
            final_goals = selected_goals
            if custom_goal and custom_goal not in final_goals:
                final_goals.append(custom_goal)
            
            if final_goals:
                # 1. Update the profile
                st.session_state.profile['goals'] = final_goals
                
                # 2. Save goals to Neo4j and the encrypted file
                cbt_progress_tracker.save_user_goals(user_id, final_goals)
                user_profile_manager.save_profile(user_id, secret_phrase, st.session_state.profile)
                
                # 3. Set the state and programmatically start the first CBT module
                st.session_state.memory.assessment_state = AssessmentState.IN_CBT_JOURNEY
                severity = last_assessment.get('severity', 'mild')
                
                # Fetch the context summary from Neo4j right before you need it.
                context_summary_text = cbt_progress_tracker.get_context_summary(user_id)                
                first_cbt_message = cbt_agent.start_cbt_journey(user_id, secret_phrase, severity, last_assessment, st.session_state.profile, context_summary_text)
              
                # 4. Add the transition to the chat and rerun
                st.session_state.messages.append({"role": "assistant", "content": first_cbt_message})
                st.rerun()
            else:
                st.warning("Please select at least one goal to begin.")
        return # Stop the rest of the app from rendering
    
    # --- MERGED & ENHANCED: Sidebar ---
    with st.sidebar:
        st.header(f"✨ My Journey")
        st.write(f"**User**: `{user_id}`")
        if st.button("Logout & End Session"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()

        # Added the "Your Goals" display to the sidebar for returning users.
        st.divider()
        st.header("🎯 Your Goals")
        user_goals = st.session_state.profile.get("goals", [])
        if user_goals:
            for goal in user_goals:
                st.info(f"- {goal}")
        else:
            st.info("Your goals will appear here once you set them.")

        st.divider()
        st.header("🆘 Crisis Helplines (India)")
        for resource, contact in INDIAN_CRISIS_RESOURCES.items():
            st.write(f"**{resource}**: {contact}")
        
        st.divider()
        st.header("📋 Assessment Progress")
        if assessment_agent and assessment_agent.active_assessment:
            assessment = assessment_agent.active_assessment
            if not assessment.completed and len(assessment.questions) > 0:
                total_questions = len(assessment.questions)
                # Your progress calculation logic
                questions_completed = assessment.current_question_index 
                progress_value = questions_completed / total_questions
                st.progress(progress_value, text=f"Question {questions_completed+1} of {total_questions}")
                st.write(f"**Type:** {assessment.type.value.upper()}")
            elif assessment.completed:
                st.success("✅ Assessment Complete!")
        else:
            st.info("No active assessment.")

        st.divider()

        st.header("👣 CBT Journey History")
        # 1. Fetch the user's entire CBT history from Neo4j
        cbt_history = cbt_progress_tracker.get_cbt_history(user_id)

        if not cbt_history:
            st.info("You have not completed any CBT exercises yet.")
        else:
            # 2. Group the responses by module for a clean display
            grouped_history = defaultdict(list)
            for response in cbt_history:
                grouped_history[response['module']].append(response)

            # Helper to get module titles from the content library
            module_titles = {
                module['module_id']: module['title']
                for package in CBT_PACKAGES.values()
                for module in package['modules']
            }

            # 3. Create an expander for each module the user has worked on
            for module_id, responses in grouped_history.items():
                title = module_titles.get(module_id, module_id) # Fallback to ID if title not found
                with st.expander(f"**{title}**"):
                    # 4. Display each question and answer pair
                    for response_item in responses:
                        # Display the question (stripping markdown for clarity)
                        question = response_item.get('question', 'N/A').replace('*', '')
                        st.write(f"**Saathi asked:** {question}")
                        
                        # Display the user's response in an info box
                        answer = response_item.get('response', 'N/A')
                        st.info(f"**You responded:** {answer}")
        st.divider()

        ############## ASSESSMENT HISTORY & TRENDS ##############
        st.header("📈 Scores Over Time")
        assessment_history = st.session_state.profile.get("assessment_history", [])
        
        phq9_tab, gad7_tab = st.tabs(["PHQ-9 (Depression)", "GAD-7 (Anxiety)"])

        with phq9_tab:
            phq9_scores = [item for item in assessment_history if item.get('assessment_type') == 'phq9']
            if len(phq9_scores) > 1:
                df = pd.DataFrame(phq9_scores)
                df['timestamp'] = pd.to_datetime(df['timestamp'])

                # --- NEW: Display a summary metric ---
                latest_score = df.iloc[-1]['total_score']
                previous_score = df.iloc[-2]['total_score']
                delta = int(latest_score - previous_score)
                st.metric(
                    label=f"Latest PHQ-9 Score ({df.iloc[-1]['timestamp'].strftime('%Y-%m-%d')})",
                    value=int(latest_score),
                    delta=f"{delta} from previous",
                    delta_color="inverse" # Lower is better
                )

                # --- NEW: Create a richer chart with Altair ---
                # Define severity bands for context
                bands = pd.DataFrame([
                    {"start": 0, "end": 4, "color": "#2ca02c", "severity": "Minimal"},
                    {"start": 5, "end": 9, "color": "#98df8a", "severity": "Mild"},
                    {"start": 10, "end": 14, "color": "#ffdd71", "severity": "Moderate"},
                    {"start": 15, "end": 19, "color": "#ff9896", "severity": "Moderately Severe"},
                    {"start": 20, "end": 27, "color": "#d62728", "severity": "Severe"},
                ])
                
                band_chart = alt.Chart(bands).mark_rect(opacity=0.3).encode(
                    y='start:Q',
                    y2='end:Q',
                    color=alt.Color('color:N', scale=None, legend=alt.Legend(title="Severity"))
                )
                
                line_chart = alt.Chart(df).mark_line(point=True, strokeWidth=3).encode(
                    x=alt.X('timestamp:T', title='Date'),
                    y=alt.Y('total_score:Q', title='Score', scale=alt.Scale(domain=[0, 27])),
                    tooltip=['timestamp:T', 'total_score:Q', 'severity:N']
                )
                
                # Combine the bands and the line
                final_chart = (band_chart + line_chart).properties(
                    title='PHQ-9 Scores Over Time'
                ).interactive()

                st.altair_chart(final_chart, use_container_width=True)
            else:
                st.info("Complete 2+ PHQ-9s to see a chart.")
        
        with gad7_tab:
            gad7_scores = [item for item in assessment_history if item.get('assessment_type') == 'gad7']
            if len(gad7_scores) > 1:
                df = pd.DataFrame(gad7_scores)
                df['timestamp'] = pd.to_datetime(df['timestamp'])

                # --- NEW: Display a summary metric ---
                latest_score = df.iloc[-1]['total_score']
                previous_score = df.iloc[-2]['total_score']
                delta = int(latest_score - previous_score)
                st.metric(
                    label=f"Latest GAD-7 Score ({df.iloc[-1]['timestamp'].strftime('%Y-%m-%d')})",
                    value=int(latest_score),
                    delta=f"{delta} from previous",
                    delta_color="inverse" # Lower is better
                )

                # --- NEW: Create a richer chart with Altair ---
                bands = pd.DataFrame([
                    {"start": 0, "end": 4, "color": "#2ca02c", "severity": "Minimal"},
                    {"start": 5, "end": 9, "color": "#98df8a", "severity": "Mild"},
                    {"start": 10, "end": 14, "color": "#ffdd71", "severity": "Moderate"},
                    {"start": 15, "end": 21, "color": "#d62728", "severity": "Severe"},
                ])

                band_chart = alt.Chart(bands).mark_rect(opacity=0.3).encode(
                    y='start:Q', y2='end:Q', color=alt.Color('color:N', scale=None)
                )

                line_chart = alt.Chart(df).mark_line(point=True, strokeWidth=3).encode(
                    x=alt.X('timestamp:T', title='Date'),
                    y=alt.Y('total_score:Q', title='Score', scale=alt.Scale(domain=[0, 21])),
                    tooltip=['timestamp:T', 'total_score:Q', 'severity:N']
                )
                
                final_chart = (band_chart + line_chart).properties(
                    title='GAD-7 Scores Over Time'
                ).interactive()

                st.altair_chart(final_chart, use_container_width=True)
            else:
                st.info("Complete 2+ GAD-7s to see a chart.")


    # --- Chat Interface ---
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # KEPT: Your custom chat input prompt
    if prompt := st.chat_input("Hello! Share how you're feeling today...be open and honest without fear of judgment."):
        st.session_state.last_interaction = datetime.now() # NEW: Update timeout
        st.session_state.memory.process_user_input(prompt)
        #st.session_state.memory.add_message("user", prompt) 
        st.session_state.messages.append({"role": "user", "content": prompt})
        
        with st.chat_message("user"):
            st.markdown(prompt)
        
        with st.chat_message("assistant"):
            with st.spinner("Saathi is thinking..."):
                response = orchestrator.handle_request(user_id, secret_phrase, prompt, st.session_state.memory, st.session_state.profile)
            st.markdown(response)

        st.session_state.messages.append({"role": "assistant", "content": response})
        # NEW: Save profile after a meaningful interaction
        user_profile_manager.save_profile(user_id, secret_phrase, st.session_state.profile)
        st.rerun()

if __name__ == "__main__":
    main()