# __init__.py
# Makes this folder a Python package.

__all__ = []  # optional — defines what’s imported when using `from core import *`
