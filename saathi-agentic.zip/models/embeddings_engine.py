"""
embeddings.py
--------------
Initializes the embedding model used for vector search.
"""

def load_embedding_model(name="text-embedding-3-large"):
    return None
