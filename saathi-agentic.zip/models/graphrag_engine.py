# saathi_app/models/graphrag_engine.py
import time
import logging
from typing import List, Dict
from langchain_community.graphs import Neo4jGraph
from config import NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD

logger = logging.getLogger(__name__)

def initialize_neo4j_graph():
    """Initializes and returns the Neo4jGraph connection object."""
    if not all([NEO4J_URI, NEO4J_USERNAME, NEO4J_PASSWORD]):
        raise ValueError("Neo4j connection details not found in environment variables.")
        
    graph = Neo4jGraph(
        url=NEO4J_URI,
        username=NEO4J_USERNAME,
        password=NEO4J_PASSWORD
    )
    # Test connection
    try:
        graph.query("RETURN 1")
        logger.info("✅ Neo4j connection successful.")
    except Exception as e:
        logger.error(f"❌ Neo4j connection failed: {e}")
        raise
    return graph

class HybridRetriever:
    """Advanced hybrid retrieval combining vector search with graph traversal"""
    
    def __init__(self, graph: Neo4jGraph, embedding_model, vector_index_name: str = "symptom_embeddings"):
        self.graph = graph
        self.embedding_model = embedding_model
        self.vector_index_name = vector_index_name
        self._initialize_vector_index()
        logger.info("✅ HybridRetriever initialized")

    def _initialize_vector_index(self):
        """Create or verify vector index exists"""
        try:
            result = self.graph.query("SHOW INDEXES YIELD name, type WHERE type = 'VECTOR' RETURN name")
            existing_indexes = [r['name'] for r in result]
            if self.vector_index_name not in existing_indexes:
                logger.info(f"Creating vector index: {self.vector_index_name}")
                self.graph.query(f"""
                    CREATE VECTOR INDEX {self.vector_index_name} IF NOT EXISTS
                    FOR (s:Symptom) ON s.embedding
                    OPTIONS {{indexConfig: {{`vector.dimensions`: 384, `vector.similarity_function`: 'cosine'}}}}
                """)
                logger.info("✅ Vector index created")
            else:
                logger.info("✅ Vector index already exists")
        except Exception as e:
            logger.warning(f"Vector index setup failed, but continuing: {e}")

    def vector_search(self, query: str, top_k: int = 10) -> List[Dict]:
        """Sanitized semantic search that prioritizes meaningful, connected nodes."""
        logger.info(f"🔍 Vector Search: {query[:50]}...")
        try:
            query_embedding = self.embedding_model.embed_query(query)
            results = self.graph.query("""
                CALL db.index.vector.queryNodes($index_name, $top_k, $query_vector)
                YIELD node, score
                OPTIONAL MATCH (node)<-[:HAS_SYMPTOM]-(d:Disorder)
                WITH node, score, count(d) as connections
                WHERE connections > 0
                RETURN node.name AS name, node.description AS description, node.category AS category, score
                ORDER BY score DESC
            """, params={
                "index_name": self.vector_index_name,
                "top_k": top_k,
                "query_vector": query_embedding
            })
            return results[:5]
        except Exception as e:
            logger.error(f"Vector search failed: {e}")
            return []

    def graph_expand(self, entity_names: List[str]) -> List[Dict]:
        """Expand entities using graph relationships"""
        if not entity_names: return []
        logger.info(f"🕸️ Expanding {len(entity_names)} entities...")
        try:
            results = self.graph.query("""
                UNWIND $names AS name
                MATCH (s:Symptom {name: name})
                OPTIONAL MATCH (s)<-[:HAS_SYMPTOM]-(d:Disorder)
                OPTIONAL MATCH (d)-[:ASSESSED_BY]->(a:Assessment)
                OPTIONAL MATCH (d)-[:TREATED_BY]->(t:Treatment)
                RETURN s.name AS symptom,
                       collect(DISTINCT {
                           name: d.name,
                           description: d.description
                       }) AS disorders,
                       collect(DISTINCT {name: a.name, full_name: a.full_name}) AS assessments,
                       collect(DISTINCT {name: t.name, type: t.type, evidence: t.evidence_level}) AS treatments
                LIMIT 10
            """, params={"names": entity_names})
            return results
        except Exception as e:
            logger.error(f"Graph expansion failed: {e}")
            return []

    def hybrid_retrieve(self, query: str, top_k: int = 5) -> Dict:
        """Complete hybrid retrieval: Vector search + Graph expansion"""
        logger.info(f"🔄 Hybrid retrieval for: {query[:50]}...")
        start_time = time.time()
        
        vector_results = self.vector_search(query, top_k)
        if not vector_results:
            return {"symptoms": [], "graph_context": [], "retrieval_method": "none", "query_time": 0}
            
        entity_names = [r['name'] for r in vector_results if r.get('name')]
        graph_context = self.graph_expand(entity_names)
        
        return {
            "symptoms": vector_results,
            "graph_context": graph_context,
            "retrieval_method": "hybrid",
            "entities_found": len(entity_names),
            "query_time": time.time() - start_time
        }