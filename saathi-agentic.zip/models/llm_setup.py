# saathi_app/models/llm_setup.py
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.embeddings import SentenceTransformerEmbeddings
from config import GOOGLE_API_KEY

def initialize_llm():
    """Initializes and returns the Gemini LLM."""
    if not GOOGLE_API_KEY:
        raise ValueError("GOOGLE_API_KEY not found in environment variables.")
    
    llm = ChatGoogleGenerativeAI(
        model="models/gemini-2.0-flash-exp",
        google_api_key=GOOGLE_API_KEY,
        temperature=0.3,
        convert_system_message_to_human=True
    )
    return llm

def initialize_embedding_model():
    """Initializes and returns the Sentence Transformer embedding model."""
    embedding_model = SentenceTransformerEmbeddings(model_name='all-MiniLM-L6-v2')
    return embedding_model