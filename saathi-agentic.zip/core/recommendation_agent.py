# saathi_app/core/recommendation_agent.py
import logging
from typing import List, Dict
from langchain_community.graphs import Neo4jGraph
from core.memory_manager import EnhancedConversationMemory
from config import INDIAN_CRISIS_RESOURCES

logger = logging.getLogger(__name__)

class RecommendationEngine:
    """Generates evidence-based, personalized recommendations."""
    
    def __init__(self, graph: Neo4jGraph):
        self.graph = graph
        logger.info("🎯 Recommendation engine initialized")

    def generate_recommendations(self, memory: EnhancedConversationMemory) -> Dict:
        """Generates a structured dictionary of recommendations."""
        logger.info("🎯 Generating personalized recommendations...")
        
        # In a real app, this would be a more complex query based on assessment results.
        # For now, we return a static set of general and crisis resources.
        recommendations = {
            "professional_referrals": [
                "Consulting a General Practitioner (GP) to discuss your mental health.",
                "Seeking a consultation with a clinical psychologist or psychiatrist."
            ],
            "self_care_strategies": [
                "Maintaining a regular sleep schedule.",
                "Engaging in regular physical activity.",
                "Practicing mindfulness or meditation."
            ],
            "resources": INDIAN_CRISIS_RESOURCES
        }
        
        if memory.risk_level in ["high", "critical"]:
            recommendations["immediate_actions"] = ["Please contact one of the provided 24/7 crisis helplines immediately."]
        
        return recommendations

class RecommendationAgent:
    """Agent wrapper for the recommendation engine."""
    
    def __init__(self, graph: Neo4jGraph):
        self.engine = RecommendationEngine(graph)

    def generate(self, memory: EnhancedConversationMemory) -> Dict:
        return self.engine.generate_recommendations(memory)