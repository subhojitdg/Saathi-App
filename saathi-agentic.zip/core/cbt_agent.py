# saathi_app/core/cbt_agent.py
import logging
import re
import json
from core.cbt_content_library import CBT_PACKAGES
from core.user_profile_manager import UserProfileManager, CbtProgressTracker
from core.prompts import journey_summary_prompt, narrative_analysis_prompt,cbt_intro_prompt, scheduling_recommendation_prompt, next_module_recommendation_prompt
from langchain_core.output_parsers import StrOutputParser


logger = logging.getLogger(__name__)

class CBTAgent:
    """Provides and manages a stateful, interactive CBT journey for the user."""
    
    def __init__(self, llm, progress_tracker: CbtProgressTracker, profile_manager: UserProfileManager):
        self.llm = llm
        self.tracker = progress_tracker
        self.profiles = profile_manager
        self.packages = CBT_PACKAGES
        self.summary_chain = journey_summary_prompt | self.llm | StrOutputParser()
        self.intro_chain = cbt_intro_prompt | self.llm | StrOutputParser()
        self.narrative_chain = narrative_analysis_prompt | self.llm | StrOutputParser()
        self.scheduling_chain = scheduling_recommendation_prompt | self.llm | StrOutputParser()
        self.recommender_chain = next_module_recommendation_prompt | self.llm | StrOutputParser()

        logger.info("Stateful CBT Agent initialized with Progress Tracker and LLM.")

    def start_specific_module(self, module_id: str, profile_data: dict) -> str:
        """Starts a specific CBT module by its ID."""
        module = None
        for package in self.packages.values():
            found_module = next((m for m in package["modules"] if m["module_id"] == module_id), None)
            if found_module:
                module = found_module
                break
        
        if not module:
            return "I'm sorry, I couldn't find the module we were about to start. Let's try again from the beginning."

        cbt_progress = profile_data["cbt_progress"]
        cbt_progress["active_package_id"] = next((pkg["id"] for pkg_id, pkg in self.packages.items() if module_id.startswith(pkg_id[:2])), None)
        cbt_progress["active_module_id"] = module_id
        cbt_progress["current_step_index"] = 0
        
        return module["steps"][0]["content"]
    
    def start_cbt_journey(self, user_id: str, secret_phrase: str, severity: str, assessment_summary: dict, profile_data: dict, context_summary: str) -> str:  
        """Selects a CBT package, starts the first module, and links it to the triggering assessment."""
        
        package_key = "moderate_intensity" if severity == "moderate" else "low_intensity"   
        package = self.packages[package_key]
        first_module = package["modules"][0]

        personalized_intro = ""
        if context_summary:
            personalized_intro = self.intro_chain.invoke({
                "module_title": first_module["title"],
                "context_summary": context_summary
            })
        
        # Update in-memory session state
        cbt_progress = profile_data["cbt_progress"]
        cbt_progress["active_package_id"] = package["id"]
        cbt_progress["active_module_id"] = first_module["module_id"]
        cbt_progress["current_step_index"] = 0
        self.profiles.save_profile(user_id, secret_phrase, profile_data)

        # Create the [:TRIGGERED_BY] link in Neo4j
        query = """
        MATCH (u:User {userId: $user_id})
        MATCH (ar:AssessmentResult) WHERE ar.timestamp = datetime($assessment_timestamp)
        MERGE (u)-[:PARTICIPATED_IN]->(s:CbtSession {moduleId: $module_id})
          ON CREATE SET s.startTime = timestamp()
        MERGE (s)-[:TRIGGERED_BY]->(ar)
        """
        params = {
            "user_id": user_id,
            "assessment_timestamp": assessment_summary.get("timestamp"),
            "module_id": first_module["module_id"]
        }
        self.tracker.graph.query(query, params)
        logger.info(f"Linked new CBT session to triggering assessment for user {user_id}.")

        first_step_content = first_module["steps"][0]["content"]
        return (f"Based on your assessment, let's start a program called '{package['title']}'.\n\n"
                f"{personalized_intro}\n\n"
                f"---\n\n{first_step_content}")
    
    def continue_cbt_journey(self, user_id: str, user_response: str, profile_data: dict) -> str:
        """
        Processes a user's response for an ACTIVE CBT session and returns the next step.
        It no longer attempts to restart a journey.
        """
        progress = profile_data["cbt_progress"]
        
        if not progress["active_module_id"]:
            logger.warning(f"continue_cbt_journey called for user {user_id} but no active module was found.")
            return "SESSION_ENDED_UNEXPECTEDLY"

        module_id = progress["active_module_id"]
        
        # Robustly find the module by searching all packages. This is now extensible.
        module = None
        for package in self.packages.values():
            found_module = next((m for m in package["modules"] if m["module_id"] == module_id), None)
            if found_module:
                module = found_module
                break
        
        if not module:
            progress["active_module_id"] = None
            return "SESSION_ENDED_UNEXPECTEDLY"
        
        current_step_index = progress["current_step_index"]
        if current_step_index < len(module["steps"]):
            step_data = module["steps"][current_step_index]

            if step_data["type"] == "narrative_prompt":
                logger.info("Analyzing user narrative with LLM...")
                analysis_json_str = self.narrative_chain.invoke({"user_narrative": user_response})
                try:
                    analysis_data = json.loads(analysis_json_str)
                    self.tracker.save_cbt_response(user_id, module_id, {"response_key": "narrative_analysis"}, analysis_json_str)
                    progress["module_responses"][module_id]["extracted_thought"] = analysis_data.get("automatic_thought")
                except json.JSONDecodeError:
                    logger.error("Failed to parse narrative analysis from LLM.")
                    progress["module_responses"][module_id]["extracted_thought"] = "the thought you mentioned"
            elif step_data["type"] in ("question", "exercise"):
                self.tracker.save_cbt_response(user_id, module_id, step_data, user_response)

        progress["current_step_index"] += 1
        
        if progress["current_step_index"] >= len(module["steps"]):
            progress["active_module_id"] = None
            progress["current_step_index"] = -1
            return f"You've completed the module: '{module['title']}'! You did a great job. We can pick up with a new module next time."
        
        next_step_data = module["steps"][progress["current_step_index"]]
        next_step_content = next_step_data["content"]
        
        if next_step_data["type"] == "dynamic_question":
            extracted_thought = progress["module_responses"][module_id].get("extracted_thought", "that thought")
            next_step_content = next_step_content.format(extracted_thought=extracted_thought)
            
        return next_step_content
    
    def summarize_journey(self, user_id: str, secret_phrase: str) -> str:
        """Loads a user's history, formats it, and uses the LLM to generate a progress summary."""
        logger.info(f"Generating mental health journey summary for user {user_id}.")
        
        # 1. Load data from both sources using the secret_phrase
        profile = self.profiles.load_profile(user_id, secret_phrase)
        assessment_history = profile.get("assessment_history", [])
        cbt_history = self.tracker.get_cbt_history(user_id)

        if not assessment_history and not cbt_history:
            return "It looks like we don't have enough history to summarize your journey yet. Let's continue working together!"

        # 2. Format the data into a readable string for the LLM
        assessment_summary = "\n".join([
            f"- {item.get('assessment_type', 'N/A').upper()} on {item.get('timestamp', 'unknown date')[:10]}: "
            f"Score {item.get('total_score')} ({item.get('severity', 'N/A')})"
            for item in assessment_history
        ]) if assessment_history else "No assessments completed yet."

        cbt_summary = "\n".join([
            f"- In module '{item.get('module', 'N/A')}': "
            f"You responded '{item.get('response', '')[:50]}...'"
            for item in cbt_history
        ]) if cbt_history else "No CBT exercises completed yet."
        
        # 3. Invoke the LLM chain with the formatted data
        response = self.summary_chain.invoke({
            "assessment_history": assessment_summary,
            "cbt_history": cbt_summary
        })
        
        return response
    
    def recommend_next_module(self, user_id: str, profile_data: dict) -> dict:
        """Recommends the next best CBT module for a returning user."""
        user_goals = profile_data.get("goals", [])
        if not user_goals:
            return {}

        completed_modules = self.tracker.get_completed_module_ids(user_id)
        
        available_modules = []
        for pkg in self.packages.values():
            for mod in pkg['modules']:
                if mod['module_id'] not in completed_modules:
                    available_modules.append({"id": mod['module_id'], "title": mod['title']})
        
        if not available_modules:
            return {"module_id": "ALL_COMPLETE", "reason": "You've completed all available modules!"}

        try:
            response_str = self.recommender_chain.invoke({
                "user_goals": json.dumps(user_goals),
                "completed_modules": json.dumps(list(completed_modules)),
                "available_modules": json.dumps(available_modules)
            })
            
            # Robustly find and parse the JSON block from the LLM's response
            json_match = re.search(r"\{.*\}", response_str, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                return json.loads(json_str)
            else:
                logger.error(f"No JSON object found in LLM recommendation. Response: {response_str}")
                return {}

        except (json.JSONDecodeError, TypeError) as e:
            logger.error(f"Failed to parse next module recommendation from LLM: {e}")
            return {}