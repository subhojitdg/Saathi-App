# saathi_app/core/tools.py
from typing import Dict, List
from config import RESPONSE_OPTIONS

def parse_assessment_response(text: str) -> int:
    """Extracts a numerical score from a user's text response."""
    text_lower = text.lower().strip()
    
    if text_lower in ['0', '1', '2', '3']:
        return int(text_lower)
    
    if any(w in text_lower for w in ['not at all', 'never', 'no']): return 0
    if any(w in text_lower for w in ['several days', 'sometimes']): return 1
    if any(w in text_lower for w in ['more than half', 'often']): return 2
    if any(w in text_lower for w in ['nearly every', 'always']): return 3
    
    return -1  # Invalid response

def format_assessment_results(summary: Dict, recommendations: Dict) -> str:
    """Creates a formatted markdown string for displaying assessment results."""
    interpretation = summary.get('interpretation', {})
    severity = summary.get('severity', 'minimal') # Get the severity

    # --- NEW: Conditionally create the CBT proposal text ---
    cbt_proposal = ""
    if severity in ("minimal", "mild", "moderate"):
        cbt_proposal = (
            "\n\n---\n\nI also see that you might benefit from a guided therapeutic program. "
            "Would you like to start your first interactive CBT session now? (Please say Yes or No)"
        )

    response = f"""
## 📊 {summary.get('assessment_type', 'Assessment').upper()} Results

| Total Score | Severity Level |
| :--- | :--- |
| **{summary.get('total_score')} / {summary.get('max_score')}** | {severity.replace('_', ' ').title()} |


### 🔍 Clinical Interpretation
{interpretation.get('description', 'Assessment complete.')}

### 📋 Recommended Next Steps
{interpretation.get('recommendation', 'Please discuss these results with a healthcare provider.')}

---

### 📞 Support Resources in India
"""
    for name, number in recommendations.get('resources', {}).items():
        response += f"- **{name}**: {number}\n"
        
    response += """
\n---
### ⚠️ Important Disclaimer
This is a screening tool, not a clinical diagnosis. Please consult with a qualified mental health professional to discuss these results and determine the best path forward.
"""
    return response