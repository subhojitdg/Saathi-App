# saathi_app/core/memory_manager.py
from datetime import datetime
from typing import Any, List, Dict, Set
import numpy as np
import logging
from config import AssessmentState, AssessmentType, CANONICAL_SYMPTOMS, COMPREHENSIVE_SYMPTOM_KEYWORDS

# New imports for advanced NLP
import nltk
from nltk.stem import WordNetLemmatizer
#from nltk.corpus import wordnet
from thefuzz import fuzz
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger(__name__)

# Helper class for advanced symptom extraction
class SymptomExtractor:
    def __init__(self, embedding_model: Any, symptoms: List[str]):
        self.embedding_model = embedding_model
        self.lemmatizer = WordNetLemmatizer()
        
        # VVV NEW: Get the tokenizer directly from the embedding model VVV
        self.tokenizer = self.embedding_model.client.tokenizer

        self.canonical_symptoms = symptoms
        self.lemmatized_keywords = self._prepare_keywords(symptoms)
        
        logger.info("Pre-computing embeddings for canonical symptoms...")
        self.symptom_vectors = np.array([self.embedding_model.embed_query(s) for s in self.canonical_symptoms])
        logger.info("Symptom embeddings computed.")

    def _prepare_keywords(self, symptoms: List[str]) -> Dict[str, str]:
        """Creates a simplified mapping from lemmatized keywords to the full canonical symptom phrase."""
        keyword_map = {}
        for phrase in symptoms:
            # Tokenize and lemmatize without POS tagging
            tokens = self.tokenizer.tokenize(phrase.lower())
            
            # Simple lemmatization for each word. It's less precise but avoids the fragile dependency.
            lemmatized_words = [self.lemmatizer.lemmatize(word) for word in tokens if not word.startswith('##')]
            
            for keyword in lemmatized_words:
                if keyword not in keyword_map:
                    keyword_map[keyword] = phrase
        return keyword_map

    def _keyword_and_fuzzy_match(self, text: str, fuzz_ratio=85) -> Set[str]:
        # VVV CHANGE: Use the new, self-contained tokenizer VVV
        lemmatized_text = {
            self.lemmatizer.lemmatize(token.lower()) 
            for token in self.tokenizer.tokenize(text)
        }
        detected = set()
        for token in lemmatized_text:
            for keyword, phrase in self.lemmatized_keywords.items():
                if fuzz.ratio(token, keyword) > fuzz_ratio:
                    detected.add(phrase)
                    break 
        return detected
        
    # ... (the rest of the class: _semantic_match, extract, etc., remains the same) ...
    def _semantic_match(self, text: str, threshold=0.75) -> Set[str]:
        if not text.strip(): return set()
        user_vector = np.array([self.embedding_model.embed_query(text)])
        scores = cosine_similarity(user_vector, self.symptom_vectors)[0]
        detected = set()
        for i, score in enumerate(scores):
            if score > threshold:
                detected.add(self.canonical_symptoms[i])
        return detected

    def extract(self, text: str) -> List[str]:
        keyword_matches = self._keyword_and_fuzzy_match(text)
        semantic_matches = self._semantic_match(text)
        all_detected_symptoms = list(keyword_matches.union(semantic_matches))
        if all_detected_symptoms:
            logger.info(f"Detected symptoms via hybrid search: {all_detected_symptoms}")
        return all_detected_symptoms

class EnhancedConversationMemory:
    """Manages the state and history of a conversation."""
    
    def __init__(self, embedding_model: Any):
        self.messages: List[Dict] = []
        self.symptoms_mentioned: set = set()
        self.risk_level: str = "low"
        self.session_start: datetime = datetime.now()
        #self.embedding_model = embedding_model
        #self.message_embeddings: List[Dict] = []
        # Initialize the powerful new extractor
        self.symptom_extractor = SymptomExtractor(embedding_model, CANONICAL_SYMPTOMS)
        self.assessment_state: AssessmentState = AssessmentState.INITIAL_SCREENING
        self.pending_assessment_type: AssessmentType | None = None
        self.assessment_history: List[Dict] = []
        self.context_question_count: int = 0

        logger.info("💭 Enhanced memory initialized")

    def add_message(self, role: str, content: str):
        """Adds a message to the history."""
        self.messages.append({"role": role, "content": content, "timestamp": datetime.now()})

    def process_user_input(self, text: str):
        """Processes user input to extract symptoms and add to memory."""
        self.add_message("user", text)
        detected_symptoms = self.symptom_extractor.extract(text)
        if detected_symptoms:
            self.symptoms_mentioned.update(detected_symptoms)

    def get_context_summary(self) -> Dict:
        """Provides a summary of the current conversation state for the LLM."""
        return {
            "session_duration_minutes": (datetime.now() - self.session_start).seconds // 60,
            "total_messages": len(self.messages),
            "symptoms_mentioned": list(self.symptoms_mentioned),
            "assessment_state": self.assessment_state.value,
            "assessments_completed": len(self.assessment_history)
        }
        
    def should_start_assessment(self) -> bool:
        """Determines if enough symptoms are present to suggest an assessment."""
        return (
            len(self.symptoms_mentioned) >= 2 and
            self.assessment_state == AssessmentState.INITIAL_SCREENING
        )