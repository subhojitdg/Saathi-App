# saathi_app/core/crisis_agent.py
import logging
from typing import Dict
from config import CRISIS_KEYWORDS

logger = logging.getLogger(__name__)

class CrisisAgent:
    """Detects crisis situations in user input."""
    
    def check(self, text: str) -> Dict:
        """
        Checks text for crisis-related keywords and returns a dictionary.
        """
        logger.info("Checking for crisis language...")
        text_lower = text.lower()
        found_keywords = [kw for kw in CRISIS_KEYWORDS if kw in text_lower]
        
        is_crisis = len(found_keywords) > 0
        
        if is_crisis:
            logger.warning(f"⚠️ CRISIS DETECTED! Keywords: {found_keywords}")
        
        return {
            "is_crisis": is_crisis,
            "keywords_found": found_keywords,
        }