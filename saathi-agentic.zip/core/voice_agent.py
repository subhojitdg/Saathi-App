# saathi_app/core/voice_agent.py
import logging
from google.cloud import speech
from google.cloud import texttospeech
import streamlit as st

logger = logging.getLogger(__name__)

class VoiceAgent:
    """Handles Speech-to-Text and Text-to-Speech conversions."""

    def __init__(self):
        try:
            self.speech_client = speech.SpeechClient()
            self.tts_client = texttospeech.TextToSpeechClient()
            logger.info("VoiceAgent initialized successfully with Google Cloud clients.")
        except Exception as e:
            logger.error(f"Failed to initialize Google Cloud clients for VoiceAgent: {e}")
            st.error("Could not connect to Google's voice services. Please check your authentication.")
            self.speech_client = None
            self.tts_client = None

    def transcribe_audio(self, audio_bytes: bytes) -> str:
        """Converts audio bytes into a text transcript."""
        if not self.speech_client:
            return ""

        audio = speech.RecognitionAudio(content=audio_bytes)
        config = speech.RecognitionConfig(
            encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,  # Common for web audio
            language_code="en-US",
        )
        try:
            response = self.speech_client.recognize(config=config, audio=audio)
            if response.results:
                transcript = response.results[0].alternatives[0].transcript
                logger.info(f"Successfully transcribed audio: '{transcript}'")
                return transcript
            else:
                logger.warning("STT returned no results.")
                return ""
        except Exception as e:
            logger.error(f"Speech-to-Text transcription failed: {e}")
            return ""

    def synthesize_speech(self, text: str) -> bytes:
        """Converts text into speech audio bytes."""
        if not self.tts_client:
            return b""

        synthesis_input = texttospeech.SynthesisInput(text=text)
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-IN",  # Indian English accent
            name="en-IN-Wavenet-D",    # A high-quality, calm female voice
            ssml_gender=texttospeech.SsmlVoiceGender.FEMALE,
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3
        )
        try:
            response = self.tts_client.synthesize_speech(
                input=synthesis_input, voice=voice, audio_config=audio_config
            )
            logger.info("Successfully synthesized speech from text.")
            return response.audio_content
        except Exception as e:
            logger.error(f"Text-to-Speech synthesis failed: {e}")
            return b""