# saathi_app/core/security.py
import base64
import os
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
import logging

logger = logging.getLogger(__name__)

# IMPORTANT: In a real production app, this SALT should be stored securely as an environment variable.
SALT = b'your_super_secret_salt_here_change_this' 

class EncryptionManager:
    """Handles encryption and decryption of user profile data."""
    
    def __init__(self, secret_phrase: str):
        self.key = self._derive_key(secret_phrase)
        self.fernet = Fernet(self.key)

    def _derive_key(self, secret_phrase: str) -> bytes:
        """Derives a stable encryption key from the user's secret phrase."""
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=SALT,
            iterations=480000, # Standard number of iterations
        )
        key = base64.urlsafe_b64encode(kdf.derive(secret_phrase.encode()))
        return key

    def encrypt(self, plaintext_data: str) -> bytes:
        """Encrypts a string and returns bytes."""
        return self.fernet.encrypt(plaintext_data.encode())

    def decrypt(self, encrypted_data: bytes) -> str:
        """Decrypts bytes and returns a string."""
        try:
            return self.fernet.decrypt(encrypted_data).decode()
        except Exception as e:
            logger.error(f"Decryption failed. This may be due to an incorrect secret phrase. Error: {e}")
            raise ValueError("Decryption failed: Incorrect secret phrase.")