# saathi_app/core/orchestrator_agent.py
import json
import logging
import re
from langchain_core.output_parsers import StrOutputParser
from core.prompts import (
    synthesis_prompt, crisis_prompt, reviewer_prompt,
    intent_classification_prompt, contextual_question_prompt,
    cbt_proposal_prompt, goal_generation_prompt
)
from core.crisis_agent import CrisisAgent
from core.clinical_assessment_agent import ClinicalAssessmentAgent
from core.recommendation_agent import RecommendationAgent
from core.retriever_agent import RetrieverAgent
from core.memory_manager import EnhancedConversationMemory
from core.tools import format_assessment_results
from config import AssessmentState
from core.cbt_agent import CBTAgent

logger = logging.getLogger(__name__)

class OrchestratorAgent:
    """The master agent that routes requests and coordinates other agents."""
    
    def __init__(self, llm, retriever_agent: RetrieverAgent, assessment_agent: ClinicalAssessmentAgent, rec_agent: RecommendationAgent, cbt_agent: CBTAgent):
        self.llm = llm
        self.retriever_agent = retriever_agent
        self.assessment_agent = assessment_agent
        self.recommendation_agent = rec_agent
        self.cbt_agent = cbt_agent
        self.crisis_agent = CrisisAgent()
        self.synthesis_chain = synthesis_prompt | self.llm | StrOutputParser()
        self.crisis_chain = crisis_prompt | self.llm | StrOutputParser()
        self.reviewer_chain = reviewer_prompt | self.llm | StrOutputParser()
        self.intent_chain = intent_classification_prompt | self.llm | StrOutputParser()
        self.context_chain = contextual_question_prompt | self.llm | StrOutputParser()
        self.cbt_proposal_chain = cbt_proposal_prompt | self.llm | StrOutputParser()
        self.goal_generation_chain = goal_generation_prompt | self.llm | StrOutputParser()
        logger.info("Orchestrator Agent initialized with all sub-agents.")

    def generate_goals(self, assessment_summary: dict, context_summary: str) -> list:
        # This function is correct.
        logger.info(f"Generating dynamic goals for assessment type: {assessment_summary.get('assessment_type')}")
        try:
            prompt_input = {
                "assessment_summary": json.dumps({
                    "assessment_type": assessment_summary.get("assessment_type"),
                    "severity": assessment_summary.get("severity")
                }),
                "context_summary": context_summary
            }
            response_str = self.goal_generation_chain.invoke(prompt_input)
            json_match = re.search(r"\{.*\}", response_str, re.DOTALL)
            if json_match:
                json_str = json_match.group(0)
                response_json = json.loads(json_str)
                logger.info("Successfully parsed goals from LLM response.")
                return response_json.get("goals", [])
            else:
                logger.error(f"No JSON object found in LLM response for goals. Response was: {response_str}")
                raise json.JSONDecodeError("No JSON found", response_str, 0)
        except (json.JSONDecodeError, TypeError) as e:
            logger.error(f"Failed to parse goals from LLM response: {e}")
            return ["Improve my overall well-being", "Learn new coping skills", "Practice self-care"]

    def handle_request(self, user_id: str, secret_phrase: str, question: str, memory: EnhancedConversationMemory, profile_data: dict) -> str:
        """The main pipeline logic for processing a user request."""
        try:
            logger.info(f"Orchestrator handling request for user '{user_id}'. Current state: {memory.assessment_state.value}")
            
            # 1. Crisis Check
            crisis_check = self.crisis_agent.check(question)
            if crisis_check["is_crisis"]:
                memory.risk_level = "critical"
                return self.crisis_chain.invoke({"question": question, "crisis_info": json.dumps(crisis_check)})

            # 2. Active CBT Journey Check
            if memory.assessment_state == AssessmentState.IN_CBT_JOURNEY:
                logger.info("Continuing a CBT session...")
                response = self.cbt_agent.continue_cbt_journey(user_id, question, profile_data)
                
                if response.startswith("MODULE_COMPLETE::"):
                    memory.assessment_state = AssessmentState.SCHEDULING_SESSION
                    message_to_user = response.split("::")[1]
                    return message_to_user
                
                elif response == "SESSION_ENDED_UNEXPECTEDLY":
                    memory.assessment_state = AssessmentState.INITIAL_SCREENING               
                    return "It looks like our last session has ended. You can start a new one anytime by sharing how you're feeling, or feel free to ask me a general question."
                
                # FIX 2: Added the missing 'return' to prevent fall-through.
                return response
            
            # 3. All Consent Flows
            if memory.assessment_state == AssessmentState.AWAITING_NEXT_MODULE_CONSENT:
                logger.info("Processing user consent for a new proposed module...")
                intent = self.intent_chain.invoke({"user_response": question}).strip().upper()
                if intent == "AFFIRMATIVE":
                    module_to_start = memory.pending_module_id
                    if module_to_start:
                        memory.assessment_state = AssessmentState.IN_CBT_JOURNEY
                        memory.pending_module_id = None # Clear the pending flag
                        return self.cbt_agent.start_specific_module(module_to_start, profile_data)
                    else: # Safety fallback
                        memory.assessment_state = AssessmentState.INITIAL_SCREENING
                        return "I'm sorry, I seem to have lost track of which module we were about to start. Can you tell me how you're feeling today?"
                else:
                    memory.assessment_state = AssessmentState.INITIAL_SCREENING
                    return "No problem at all. What's on your mind today?"
            
            elif memory.assessment_state == AssessmentState.AWAITING_CONSENT:
                logger.info("Processing user consent for assessment...")
                intent = self.intent_chain.invoke({"user_response": question}).strip().upper()
                if intent == "AFFIRMATIVE":
                    memory.assessment_state = AssessmentState.DEEP_DIVE
                    return self.assessment_agent.start(memory.pending_assessment_type)
                else:
                    memory.assessment_state = AssessmentState.INITIAL_SCREENING
                    return "No problem. We can continue our conversation without the formal assessment. What's on your mind?"

            # 4. Context Gathering Flow
            if memory.assessment_state == AssessmentState.CONTEXT_GATHERING:
                logger.info("Continuing context gathering conversation...")
                if memory.context_question_count < 3:
                    memory.context_question_count += 1
                    history_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in memory.messages])
                    next_question = self.context_chain.invoke({"conversation_history": history_str})
                    return next_question
                else:
                    logger.info("Context gathering complete. Summarizing and proposing assessment.")
                    history_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in memory.messages])
                    summarizer_prompt = f"Summarize the user's story from this conversation into a concise, first-person narrative (e.g., 'I am feeling lost because...'):\n\n{history_str}"
                    ai_message_summary = self.llm.invoke(summarizer_prompt)
                    context_summary_text = ai_message_summary.content 
                    self.cbt_agent.tracker.save_context_summary(user_id, context_summary_text)
                    memory.context_question_count = 0
                    memory.assessment_state = AssessmentState.AWAITING_CONSENT
                    assessment_type = self.assessment_agent.determine_assessment_type(list(memory.symptoms_mentioned), {})
                    memory.pending_assessment_type = assessment_type
                    return (f"Thank you for sharing that with me. It sounds like a really tough situation. To help us better understand how these feelings are impacting your daily life, would you be open to a brief, standardized screening? "
                            f"The **{assessment_type.value.upper()}** is a common tool for this. (Please say Yes or No)")
            
            # 5. Assessment in Progress Flow
            if memory.assessment_state == AssessmentState.DEEP_DIVE:
                logger.info("Continuing an assessment in progress...")
                response = self.assessment_agent.process_response(question)
                if response == "ASSESSMENT_COMPLETE":
                    logger.info("Assessment is now complete. Preparing summary and recommendations.")
                    summary = self.assessment_agent.get_summary()
                    self.cbt_agent.tracker.save_assessment_result(user_id, summary)
                    profile_data['assessment_history'].append(summary)
                    severity = summary.get('severity', 'minimal')
                    if severity in ("severe", "moderately_severe"): memory.risk_level = "high"
                    elif severity == "moderate": memory.risk_level = "medium"
                    else: memory.risk_level = "low"
                    recommendations = self.recommendation_agent.generate(memory)
                    rec_text = format_assessment_results(summary, recommendations)
                    if severity in ("minimal", "mild", "moderate"):
                        memory.assessment_state = AssessmentState.AWAITING_CBT_CONSENT
                        context_summary = self.cbt_agent.tracker.get_context_summary(user_id)
                        proposal = self.cbt_proposal_chain.invoke({
                            "assessment_summary": f"{summary.get('severity')} {summary.get('assessment_type')}",
                            "context_summary": context_summary
                        })
                        return rec_text + "\n\n---\n\n" + proposal
                    else:
                        memory.assessment_state = AssessmentState.RECOMMENDATION
                        return rec_text
                return response

            # 6. Default RAG Flow
            memory.process_user_input(question)

            if memory.assessment_state == AssessmentState.INITIAL_SCREENING and profile_data.get("assessment_history"):
                # Use a simple keyword check for the user's intent.
                continue_intent_keywords = ["continue", "next", "session", "module", "start", "cbt", "journey"]
                if any(word in question.lower() for word in continue_intent_keywords):
                    logger.info("Returning user expressed intent to continue journey. Starting a new CBT module.")
                    
                    # Re-use the logic from our other flows to correctly start a new session
                    last_assessment = profile_data["assessment_history"][-1]
                    severity = last_assessment.get("severity", "mild")
                    context_summary = self.cbt_agent.tracker.get_context_summary(user_id)
                    memory.assessment_state = AssessmentState.IN_CBT_JOURNEY
                    
                    # Correctly call start_cbt_journey with all required arguments
                    return self.cbt_agent.start_cbt_journey(user_id, secret_phrase, severity, last_assessment, profile_data, context_summary)

            if memory.should_start_assessment():
                logger.info("Initial symptoms detected. Beginning context gathering.")
                memory.assessment_state = AssessmentState.CONTEXT_GATHERING
                memory.context_question_count = 1
                history_str = "\n".join([f"{msg['role']}: {msg['content']}" for msg in memory.messages])
                first_question = self.context_chain.invoke({"conversation_history": history_str})
                return first_question

            hybrid_results = self.retriever_agent.retrieve(question)
            logger.info("No special flow triggered. Generating standard synthesis response.")
            draft_response = self.synthesis_chain.invoke({
                "question": question,
                "hybrid_context": json.dumps(hybrid_results, indent=2, default=str),
                "memory_context": json.dumps(memory.get_context_summary(), indent=2, default=str)
            })
        
            # 7. Review Step
            logger.info("Submitting draft response to Reviewer Agent.")
            review_result_str = self.reviewer_chain.invoke({"draft_response": draft_response})
            try:
                review_result = json.loads(review_result_str)
                if review_result.get("decision") == "APPROVE":
                    logger.info("Reviewer approved the response.")
                    return draft_response
                else:
                    logger.warning(f"Reviewer REJECTED the response. Reason: {review_result.get('reason')}")
                    return "I've processed your message, but I recommend discussing these feelings with a qualified healthcare professional for the best guidance."
            except json.JSONDecodeError:
                logger.error("Reviewer did not return valid JSON. Falling back to safety message.")
                return "I'm having a little trouble formulating a response right now. It's always a good idea to speak with a healthcare provider for specific advice."

        except Exception as e:
            logger.error(f"An unexpected error occurred in OrchestratorAgent: {e}", exc_info=True)
            return "I'm sorry, I encountered a technical issue and couldn't process your request. Please try again."