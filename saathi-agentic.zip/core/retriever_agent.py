# saathi_app/core/retriever_agent.py
import logging
from typing import Dict
from models.graphrag_engine import HybridRetriever

logger = logging.getLogger(__name__)

class RetrieverAgent:
    """An agent that interfaces with the Hybrid Retriever to fetch knowledge."""

    def __init__(self, retriever: HybridRetriever):
        self.retriever = retriever
        logger.info("Retriever Agent initialized.")

    def retrieve(self, query: str) -> Dict:
        """
        Performs a hybrid retrieval from the knowledge graph.
        """
        logger.info(f"Retriever agent executing query: {query}")
        return self.retriever.hybrid_retrieve(query)