# saathi_app/core/user_profile_manager.py
import json
import os
import logging
from typing import Dict, Any, List
from langchain_community.graphs import Neo4jGraph # Ensure Neo4jGraph is imported if needed
from core.security import EncryptionManager 

logger = logging.getLogger(__name__)
PROFILE_DIR = "user_profiles"

class UserProfileManager:
    def __init__(self):
        if not os.path.exists(PROFILE_DIR):
            os.makedirs(PROFILE_DIR)
            logger.info(f"Created user profiles directory at: {PROFILE_DIR}")

    def _create_new_profile(self, user_id: str) -> Dict[str, Any]:
        return {
            "user_id": user_id,
            "assessment_history": [],
            # ... (cbt_progress remains the same)
            # VVV ADD THIS NEW FIELD VVV
            "scheduled_session": None # Will store {module_id: '...', time: '...'}
        }
    
    def _get_profile_path(self, user_id: str) -> str:
        return os.path.join(PROFILE_DIR, f"{user_id}.json.enc") # Encrypted file extension

    def load_profile(self, user_id: str, secret_phrase: str) -> Dict[str, Any]:
        """Loads and decrypts a user's profile."""
        profile_path = self._get_profile_path(user_id)
        if os.path.exists(profile_path):
            try:
                encryption_manager = EncryptionManager(secret_phrase)
                with open(profile_path, 'rb') as f: # Read in binary mode
                    encrypted_data = f.read()
                
                decrypted_json = encryption_manager.decrypt(encrypted_data)
                return json.loads(decrypted_json)
            except (ValueError, IOError) as e:
                logger.error(f"Could not load or decrypt profile for {user_id}: {e}")
                raise  # Re-raise the exception to be caught by the UI
        else:
            return self._create_new_profile(user_id)

    def save_profile(self, user_id: str, secret_phrase: str, profile_data: Dict[str, Any]):
        """Encrypts and saves a user's profile data."""
        profile_path = self._get_profile_path(user_id)
        try:
            encryption_manager = EncryptionManager(secret_phrase)
            json_data = json.dumps(profile_data, indent=4)
            encrypted_data = encryption_manager.encrypt(json_data)
            
            with open(profile_path, 'wb') as f: # Write in binary mode
                f.write(encrypted_data)
            logger.info(f"Successfully encrypted and saved profile for user {user_id}.")
        except IOError as e:
            logger.error(f"Error saving profile for {user_id}: {e}")

    def _create_new_profile(self, user_id: str) -> Dict[str, Any]:
        """Creates a default structure for a new user profile."""
        return {
            "user_id": user_id,
            "assessment_history": [],
            "cbt_progress": {
                "active_package_id": None,
                "active_module_id": None,
                "current_step_index": -1,
                "module_responses": {}
            }
        }
    
class CbtProgressTracker:
    """Handles saving and retrieving CBT progress directly to/from Neo4j."""
    
    def __init__(self, graph: Neo4jGraph):
        self.graph = graph
        # Create a uniqueness constraint on User nodes for better performance
        try:
            self.graph.query("CREATE CONSTRAINT IF NOT EXISTS FOR (u:User) REQUIRE u.userId IS UNIQUE")
            logger.info("User ID uniqueness constraint ensured in Neo4j.")
        except Exception as e:
            logger.warning(f"Could not create Neo4j constraint: {e}")

    def record_user_consent(self, user_id: str):
        """
        Finds or creates a User node and sets properties to record that
        the user has given consent, including a timestamp.
        """
        query = """
        MERGE (u:User {userId: $user_id})
        SET u.consentGiven = true, u.consentTimestamp = datetime()
        """
        try:
            self.graph.query(query, {"user_id": user_id})
            logger.info(f"Successfully recorded consent for user {user_id} in Neo4j.")
        except Exception as e:
            logger.error(f"Failed to record consent for user {user_id}: {e}")    
    
    def save_cbt_response(self, user_id: str, module_id: str, step_data: Dict, user_response: str):
        """Saves a user's response to a specific step in a CBT module."""
        query = """
        // Find or create the User and CbtModule nodes
        MERGE (u:User {userId: $user_id})
        MERGE (m:CbtModule {moduleId: $module_id})
        
        // Find or create a CbtSession linking this user to this module
        // This groups all responses for one module completion together
        MERGE (u)-[:PARTICIPATED_IN]->(s:CbtSession {moduleId: $module_id})
          ON CREATE SET s.startTime = timestamp()
        
        // Create the new UserResponse node
        CREATE (r:UserResponse {
          stepKey: $step_key,
          question: $question,
          response: $user_response,
          timestamp: timestamp()
        })
        
        // Link the session to the new response
        MERGE (s)-[:HAS_RESPONSE]->(r)
        MERGE (s)-[:IS_MODULE]->(m) // Ensure session is linked to the module
        """
        params = {
            "user_id": user_id,
            "module_id": module_id,
            "step_key": step_data.get("response_key"),
            "question": step_data.get("content"),
            "user_response": user_response
        }
        self.graph.query(query, params)
        logger.info(f"Saved CBT response for user {user_id} to Neo4j.")

    def get_cbt_history(self, user_id: str) -> List[Dict]:
        """Retrieves a user's entire CBT response history from Neo4j."""
        query = """
        MATCH (u:User {userId: $user_id})-[:PARTICIPATED_IN]->(s:CbtSession)-[:HAS_RESPONSE]->(r:UserResponse)
        RETURN s.moduleId AS module, r.stepKey AS step, r.question AS question, r.response AS response, r.timestamp AS timestamp
        ORDER BY r.timestamp ASC
        """
        result = self.graph.query(query, {"user_id": user_id})
        logger.info(f"Retrieved {len(result)} CBT history records for user {user_id}.")
        return result
    
    def get_completed_module_ids(self, user_id: str) -> set:
        """Retrieves a unique set of module IDs the user has participated in."""
        query = """
        MATCH (u:User {userId: $user_id})-[:PARTICIPATED_IN]->(s:CbtSession)
        RETURN s.moduleId AS moduleId
        """
        try:
            result = self.graph.query(query, {"user_id": user_id})
            return {item['moduleId'] for item in result}
        except Exception as e:
            logger.error(f"Failed to retrieve completed modules for user {user_id}: {e}")
            return set() # Return an empty set on error
    
    def save_user_goals(self, user_id: str, goals: list):
        query = """
        MATCH (u:User {userId: $user_id})
        SET u.goals = $goals
        """
        self.graph.query(query, {"user_id": user_id, "goals": goals})
    
    def save_context_summary(self, user_id: str, summary_text: str):
        """Saves the user's narrated context as a node in Neo4j."""
        query = """
        MERGE (u:User {userId: $user_id})
        // Create a new summary node with the text and a timestamp
        CREATE (cs:ContextualSummary {summary: $summary_text, timestamp: datetime()})
        // Connect the user to their story
        MERGE (u)-[:HAS_CONTEXT]->(cs)
        """
        params = {"user_id": user_id, "summary_text": summary_text}
        self.graph.query(query, params)
        logger.info(f"Saved contextual summary for user {user_id} to Neo4j.")
    
    def get_context_summary(self, user_id: str) -> str:
        """Retrieves the user's most recent contextual summary from Neo4j."""
        query = """
        MATCH (u:User {userId: $user_id})-[:HAS_CONTEXT]->(cs:ContextualSummary)
        RETURN cs.summary AS summary
        ORDER BY cs.timestamp DESC
        LIMIT 1
        """
        result = self.graph.query(query, {"user_id": user_id})
        if result:
            return result[0]["summary"]
        return "" # Return empty string if no context is found
    
    def save_assessment_result(self, user_id: str, summary: Dict):
        """Saves an assessment and links it to the user's latest context summary."""
        query = """
        // Find the user and their most recent context summary
        MATCH (u:User {userId: $user_id})
        OPTIONAL MATCH (u)-[:HAS_CONTEXT]->(cs:ContextualSummary)
        WITH u, cs ORDER BY cs.timestamp DESC LIMIT 1

        // Create the new AssessmentResult node
        CREATE (ar:AssessmentResult {
            type: $type,
            score: $score,
            severity: $severity,
            timestamp: datetime($timestamp)
        })
        
        // Link the user to the assessment
        MERGE (u)-[:COMPLETED_ASSESSMENT]->(ar)

        // If a context summary was found, link it to the assessment
        WITH ar, cs
        WHERE cs IS NOT NULL
        MERGE (cs)-[:LED_TO]->(ar)
        """
        params = {
            "user_id": user_id,
            "type": summary.get("assessment_type"),
            "score": summary.get("total_score"),
            "severity": summary.get("severity"),
            "timestamp": summary.get("timestamp")
        }
        self.graph.query(query, params)
        logger.info(f"Saved assessment result for user {user_id} and linked to context.")