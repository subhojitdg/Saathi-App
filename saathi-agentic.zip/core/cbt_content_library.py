# saathi_app/core/cbt_content_library.py

CBT_PACKAGES = {
    "low_intensity": {
        "id": "low_intensity_package_1",
        "title": "Foundations of Well-being",
        "description": "A gentle introduction to understanding your thoughts and making small, positive changes.",
        "modules": [
            {
                "module_id": "LI_M1",
                "title": "Module 1: Understanding the Mind-Body Connection",
                "steps": [
                    {"type": "info", "content": "Welcome to your first CBT session! Today, we'll explore the connection between your thoughts, feelings, and actions. What you think can directly affect how you feel and what you do. Let's start with a simple check-in."},
                    {"type": "question", "content": "On a scale of 1 to 10 (where 1 is very low and 10 is very high), how would you rate your energy level right now?", "response_key": "energy_level_start"},
                    {"type": "info", "content": "Thank you. Now, let's talk about 'thought records'. A thought record helps you identify and challenge unhelpful thoughts. The goal isn't to force positivity, but to find a more balanced perspective."},
                    {"type": "exercise", "content": "Think about a minor situation recently that made you feel upset or anxious. Can you briefly describe the situation?", "response_key": "situation_description"},
                    {"type": "info", "content": "Great. That's a perfect start. In our next session, we'll break down that situation further. For now, just noticing these connections is a huge step. Well done today!"},
                ]
            },
            {
                "module_id": "LI_M2",
                "title": "Module 2: The Power of Action (Behavioral Activation)",
                "steps": [
                    {"type": "info", "content": "Sometimes when we feel low, we stop doing the things we enjoy, which can make us feel even worse. This is called the 'downward spiral.' Behavioral Activation helps reverse this by scheduling small, positive activities."},
                    {"type": "question", "content": "What is one small, simple activity you used to enjoy, even a little bit? It could be listening to a song, stretching for 5 minutes, or stepping outside for fresh air.", "response_key": "pleasant_activity_idea"},
                    {"type": "exercise", "content": "That's a great idea. Now, let's make a plan. When, in the next two days, could you realistically do that for just 5-10 minutes? Be specific (e.g., 'tomorrow after lunch').", "response_key": "activity_plan"},
                    {"type": "info", "content": "Perfect. It's scheduled. The goal isn't to feel amazing instantly, but just to take the action. You've done a wonderful job setting a positive goal today."}
                ]
            },
            {
                "module_id": "LI_M3",
                "title": "Module 3: Anchoring Yourself (5-4-3-2-1 Grounding)",
                "steps": [
                    {"type": "info", "content": "When you feel anxious or overwhelmed, your mind can race. A 'grounding' technique can bring your focus back to the present moment and calm your nervous system. Let's try one called '5-4-3-2-1'."},
                    {"type": "question", "content": "First, take a slow, deep breath. Now, look around you and name 5 separate things you can see. What are they?", "response_key": "5_things_seen"},
                    {"type": "question", "content": "Great. Now, focus on the sense of touch. What are 4 things you can physically feel right now? (e.g., your feet on the floor, the texture of your chair).", "response_key": "4_things_felt"},
                    {"type": "question", "content": "Good. Next, listen carefully. What are 3 things you can hear right now?", "response_key": "3_things_heard"},
                    {"type": "question", "content": "Almost there. Now, what are 2 things you can smell?", "response_key": "2_things_smelled"},
                    {"type": "question", "content": "Finally, what is 1 thing you can taste?", "response_key": "1_thing_tasted"},
                    {"type": "info", "content": "Well done. You've just anchored yourself in the present moment. This is a tool you can use anytime you feel your thoughts starting to spiral."}
                ]
            },
            {
                "module_id": "LI_M4",
                "title": "Module 4: Containing Your Worries (Worry Time)",
                "steps": [
                    {"type": "info", "content": "Constant worry can be exhausting. A powerful technique to manage this is to schedule a specific 'Worry Time' each day. This puts you in control, rather than letting worry control you."},
                    {"type": "exercise", "content": "Let's schedule it. Choose a 15-minute slot that you can consistently set aside each day (e.g., '4:30 PM to 4:45 PM'). What time works for you?", "response_key": "worry_time_schedule"},
                    {"type": "info", "content": "Great. Here's how it works: Throughout the day, when a worry pops into your head, acknowledge it, write it down, and tell yourself, 'I will think about this during my scheduled Worry Time.'"},
                    {"type": "question", "content": "When you postpone a worry, what is one thing you can do to gently bring your focus back to the present moment?", "response_key": "refocus_technique"},
                    {"type": "info", "content": "That's a perfect strategy. This technique takes practice, but it's a very effective way to reclaim your mental space from worry. You've set a great plan."}
                ]
            },
            {
                "module_id": "LI_M5",
                "title": "Module 5: Practicing Self-Kindness (Self-Compassion Break)",
                "steps": [
                    {"type": "info", "content": "We're often much harder on ourselves than we would be on a friend. This exercise is a brief 'Self-Compassion Break' to practice treating yourself with kindness, especially when you're struggling."},
                    {"type": "exercise", "content": "First, think of a situation that is causing you stress right now. Silently say to yourself: 'This is a moment of suffering.' This is mindfulness—simply acknowledging the pain without judgment.", "response_key": "acknowledged_pain"},
                    {"type": "info", "content": "Next, gently say to yourself: 'Suffering is a part of life.' This reminds you that you are not alone in your feelings. This is common humanity."},
                    {"type": "exercise", "content": "Finally, place a hand over your heart and say to yourself: 'May I be kind to myself in this moment.' What is one kind thought you can offer yourself right now?", "response_key": "kind_thought"},
                    {"type": "info", "content": "Thank you. Remember this simple 3-step break. You can use it anytime you notice you're being self-critical. It's a powerful way to offer yourself support."}
                ]
            }
        ]
    },
    "moderate_intensity": {
        "id": "moderate_intensity_package_1",
        "title": "Building Resilience",
        "description": "A structured program to actively challenge negative thought patterns and build coping strategies.",
        "modules": [
            {
                "module_id": "MI_M1",
                "title": "Module 1: Challenging Automatic Negative Thoughts (ANTs)",
                "steps": [
                    {"type": "info", "content": "Welcome. This program is designed to help you actively identify and challenge the automatic negative thoughts, or 'ANTs', that can impact your mood."},
                    {"type": "question", "content": "Let's start by identifying a thought you've had frequently this week that was distressing. What was the thought?", "response_key": "negative_thought"},
                    {"type": "exercise", "content": "Thank you for sharing. Now, let's be a detective. What is the hard evidence that supports this thought? And what is the evidence that contradicts it?", "response_key": "evidence_for_against"},
                    {"type": "exercise", "content": "Considering the evidence, is there a more balanced or alternative way to view the situation? Try to re-write your original thought in a more neutral way.", "response_key": "balanced_thought"},
                    {"type": "info", "content": "Excellent work. This process of questioning our thoughts is a core skill in CBT. You've done a great job. We'll build on this in our next session."},
                ]
            },
            {
                "module_id": "MI_M2",
                "title": "Module 2: Deconstructing a Recent Experience",
                "steps": [
                    {"type": "info", "content": "In this exercise, we'll work through a recent event together. Thinking about specific situations is a powerful way to understand our thought patterns."},
                    {"type": "narrative_prompt", "content": "Please take a moment to describe a recent situation that has been on your mind or caused you some distress. Don't worry about the structure, just write what happened and how you felt."},
                    {"type": "dynamic_question", "content": "Thank you for sharing. It sounds like the core thought here was, '{extracted_thought}'. Is that correct?", "response_key": "thought_confirmation"},
                    {"type": "exercise", "content": "Okay. Now, let's challenge that thought: '{extracted_thought}'. What is the evidence that this thought is 100% true?", "response_key": "evidence_for"},
                    {"type": "info", "content": "Great work. You've successfully deconstructed a complex experience into a thought you can work with."}
                ]
            },
            {
                "module_id": "MI_M3",
                "title": "Module 3: Identifying Thinking Traps (Cognitive Distortions)",
                "steps": [
                    {"type": "info", "content": "Our minds sometimes use mental shortcuts or 'Thinking Traps' that aren't accurate. Learning to spot them is the first step to challenging them. Let's look at two common ones:"},
                    {"type": "info", "content": "1. **Black-and-White Thinking**: Seeing things in all-or-nothing terms (e.g., 'If I don't get this job, my career is a failure').\n2. **Catastrophizing**: Expecting the worst-case scenario to happen (e.g., 'This headache is probably a brain tumor')."},
                    {"type": "question", "content": "Think about a recent worry you've had. Can you briefly describe the thought?", "response_key": "worry_thought"},
                    {"type": "exercise", "content": "Thank you. Looking at that thought, does it seem to fit into 'Black-and-White Thinking', 'Catastrophizing', or neither? Let me know what you think.", "response_key": "distortion_identification"},
                    {"type": "info", "content": "Excellent. Just being able to name the thinking trap reduces its power. This is a skill we will continue to build on. You've done great work today."}
                ]
            },
            {
                "module_id": "MI_M4",
                "title": "Module 4: A Deeper Look at Thinking Traps",
                "steps": [
                    {"type": "info", "content": "Last time, we touched on a couple of 'Thinking Traps.' Let's expand our toolkit. Here are a few more common ones:"},
                    {"type": "info", "content": "1. **Fortune Telling**: Predicting the future negatively without considering other, more likely outcomes.\n2. **Mind Reading**: Assuming you know what other people are thinking, usually about you.\n3. **Labeling**: Assigning a fixed, global label to yourself or others (e.g., 'I'm a failure') instead of seeing the specific behavior."},
                    {"type": "narrative_prompt", "content": "Please describe a recent situation where you felt upset, anxious, or frustrated."},
                    {"type": "dynamic_question", "content": "Thank you for sharing. It sounds like the key thought there was, '{extracted_thought}'. Looking at our list (Fortune Telling, Mind Reading, Labeling), does that thought seem to fit any of these traps?", "response_key": "distortion_identification_2"},
                    {"type": "info", "content": "Great observation. Being able to accurately label these traps is a huge step in taking away their power. You're building a very valuable skill."}
                ]
            },
            {
                "module_id": "MI_M5",
                "title": "Module 5: Overcoming Obstacles (Structured Problem-Solving)",
                "steps": [
                    {"type": "info", "content": "When we're struggling, problems can feel like unclimbable mountains. This exercise helps us break them down into smaller, manageable steps."},
                    {"type": "question", "content": "What is one specific problem that's been weighing on you lately?", "response_key": "problem_definition"},
                    {"type": "exercise", "content": "Okay. Now, let's brainstorm at least three potential solutions, no matter how small or 'silly' they might seem. The goal here is quantity, not quality. What are some ideas?", "response_key": "solution_brainstorm"},
                    {"type": "question", "content": "Great list. Looking at those options, which one feels like the most realistic 'first step' you could take, even if it doesn't solve the whole problem?", "response_key": "first_step_selection"},
                    {"type": "info", "content": "That is a perfect first step. You've successfully taken an overwhelming problem and turned it into a concrete, actionable plan. This is a skill you can apply to any challenge you face."}
                ]
            },
            {
                "module_id": "MI_M6",
                "title": "Module 6: Your Future Resilience Plan",
                "steps": [
                    {"type": "info", "content": "You've developed some incredible skills during our sessions. Now, let's create a plan to help you navigate future challenges and maintain your progress. This is your personal resilience plan. 展望"},
                    {"type": "question", "content": "First, let's identify early warning signs. What are 1-3 specific changes in your feelings, thoughts, or behaviors that might signal you're slipping back into old patterns? (e.g., 'I stop replying to my friends,' 'I start thinking in all-or-nothing terms again').", "response_key": "relapse_warning_signs"},
                    {"type": "question", "content": "That's great self-awareness. Now, based on what you've learned here, what are the top 3 most effective coping strategies you can use the moment you spot those warning signs?", "response_key": "relapse_coping_strategies"},
                    {"type": "info", "content": "Excellent. You now have a concrete plan. Remember to review it from time to time. You've successfully learned how to become your own guide, and you're well-equipped to handle future challenges. We're always here if you need a refresher."}
                ]
            },
            {
                "module_id": "MI_M7",
                "title": "Module 7: Discovering Your Core Beliefs",
                "steps": [
                    {"type": "info", "content": "Our day-to-day negative thoughts often grow from deeper roots called 'core beliefs.' These are fundamental rules we hold about ourselves or the world. Let's see if we can uncover one. 核心信念"},
                    {"type": "narrative_prompt", "content": "To start, please describe a recent situation that triggered a strong negative thought and made you feel upset."},
                    {"type": "dynamic_question", "content": "Thank you for sharing. The automatic thought you had was, '{extracted_thought}'. Let's use a technique called the 'Downward Arrow'. If that thought were 100% true, what would that mean about you as a person?", "response_key": "downward_arrow_1"},
                    {"type": "exercise", "content": "Okay. And if *that* were true, what would be the worst part about it? What would it say about your life or your future?", "response_key": "downward_arrow_2"},
                    {"type": "info", "content": "Thank you for going through that difficult exercise. Often, at the bottom of these thoughts, we find a core belief. It might be something like 'I am not good enough' or 'I am unlovable.' Just noticing this belief is the most important step in learning how to challenge it."}
                ]
            },
            {
                "module_id": "MI_M8",
                "title": "Module 8: Building a Fear Ladder",
                "steps": [
                    {"type": "info", "content": "For anxiety, gradually and safely facing our fears is a powerful way to overcome them. This technique is called 'Graded Exposure.' We'll design a series of small, manageable steps to help you confront a fear. 階梯練習"},
                    {"type": "question", "content": "What is one specific situation or activity you have been avoiding due to fear or anxiety? (e.g., 'making a phone call,' 'driving on the highway,' 'attending a social event').", "response_key": "avoided_situation"},
                    {"type": "exercise", "content": "Okay. Let's build your 'Fear Ladder.' First, what is the absolute smallest, easiest first step you could take related to that? On a scale of 1-10, how much anxiety would it cause?", "response_key": "ladder_step_1"},
                    {"type": "exercise", "content": "Great. Now, what would be a slightly more challenging second step? Again, rate its anxiety level from 1-10.", "response_key": "ladder_step_2"},
                    {"type": "exercise", "content": "Excellent. Let's do one more. What's a third step that feels a bit more difficult than the last one?", "response_key": "ladder_step_3"},
                    {"type": "info", "content": "You've just built the first few rungs of your ladder. The goal is to start with the easiest step, practice it until your anxiety decreases, and only then move to the next. You've created a clear, actionable roadmap to build your confidence and overcome this fear."}
                ]
            }
        ]
    },

    # --- NEW PACKAGE: Social Anxiety ---
    "social_anxiety_package_1": {
        "id": "social_anxiety_package_1",
        "title": "Building Social Confidence",
        "description": "A step-by-step program to understand social anxiety, challenge self-critical thoughts, and build confidence in social settings.",
        "modules": [
            {
                "module_id": "SA_M1",
                "title": "Module 1: Understanding Your Social Worries",
                "steps": [
                    {"type": "info", "content": "Social anxiety often comes from a fear of being judged negatively. In this module, we'll learn to look at these fears like a detective and examine the evidence."},
                    {"type": "question", "content": "Describe a recent social situation you were worried about or avoided. What was the specific outcome you were afraid of? (e.g., 'I was afraid people would think I'm boring at the party').", "response_key": "social_fear_scenario"},
                    {"type": "exercise", "content": "That's a very common fear. This is an 'automatic negative thought.' Let's challenge it. What's a more realistic or balanced thought? For example, instead of 'Everyone will think I'm boring,' a more balanced thought might be, 'I might not connect with everyone, but I'll probably have a pleasant chat with a few people.'", "response_key": "social_balanced_thought"},
                    {"type": "info", "content": "Excellent. The goal isn't to predict a perfect outcome, but to challenge our worst-case predictions and approach situations with a more balanced mindset. You did a great job."}
                ]
            },
            {
                "module_id": "SA_M2",
                "title": "Module 2: Shifting Your Attentional Focus",
                "steps": [
                    {"type": "info", "content": "When we're socially anxious, our attention is often focused inward on ourselves—how we're standing, what we're saying. A powerful skill is to shift our focus outward, onto the people we're with and the environment around us."},
                    {"type": "exercise", "content": "Think about the social situation you mentioned. What are two things you could choose to focus on externally instead of internally? (e.g., 'Focus on what the other person is saying,' or 'Notice the music playing in the room').", "response_key": "external_focus_points"},
                    {"type": "info", "content": "Those are great targets. Your homework is to try practicing this in your next brief social interaction, even just for a minute. Shift your spotlight outward. Well done today."}
                ]
            }
        ]
    },

    # --- NEW PACKAGE: OCD (ERP) ---
    "ocd_erp_package_1": {
        "id": "ocd_erp_package_1",
        "title": "Taking Control of OCD",
        "description": "Learn the principles of Exposure and Response Prevention (ERP) to reduce the power of obsessions and compulsions.",
        "modules": [
            {
                "module_id": "OCD_M1",
                "title": "Module 1: Introduction to ERP",
                "steps": [
                    {"type": "info", "content": "The most effective treatment for OCD is a technique called ERP. It involves two parts: **Exposure** (safely and gradually facing your obsessive thoughts or situations) and **Response Prevention** (choosing not to do the compulsive ritual). This process teaches your brain that the anxiety will decrease on its own, without the ritual."},
                    {"type": "question", "content": "To start, let's identify one common obsessive thought or urge you have and the compulsion that follows. For example, 'Obsession: My hands are contaminated. Compulsion: I wash them for five minutes.'", "response_key": "ocd_cycle_example"},
                    {"type": "exercise", "content": "Thank you for sharing. Now, let's think about 'Response Prevention.' What would be a very small, manageable reduction in that ritual? For example, 'I will only wash my hands for four minutes instead of five,' or 'I will wait one minute before starting to wash.'", "response_key": "erp_first_step"},
                    {"type": "info", "content": "That's a perfect first step. ERP works by teaching your brain that the bad thing you fear doesn't happen, even if you reduce the ritual. It takes courage, and you've just designed the first step on your path to taking back control."}
                ]
            },
            {
                "module_id": "OCD_M2",
                "title": "Module 2: Building Your First ERP Ladder",
                "steps": [
                    {"type": "info", "content": "In ERP, we face our fears step-by-step using a 'Fear Ladder.' We'll design a list of exposures, from easiest to hardest, for the OCD cycle you mentioned."},
                    {"type": "question", "content": "Let's start at the bottom. What's a very low-anxiety exposure you could do? (e.g., 'Touch a doorknob and wait 5 seconds before washing'). On a scale of 1-10, how much anxiety would this cause?", "response_key": "erp_ladder_step1"},
                    {"type": "question", "content": "Great. Now, what's a slightly more challenging step in the middle of the ladder? (e.g., 'Touch the doorknob and wait 1 minute before washing'). What would you rate its anxiety level?", "response_key": "erp_ladder_step2"},
                    {"type": "question", "content": "Excellent. Finally, what's a high-level, very challenging exposure that would be the top of your ladder? (e.g., 'Touch a public doorknob and then eat a snack without washing'). What would you rate its anxiety?", "response_key": "erp_ladder_step3"},
                    {"type": "info", "content": "You've just built a roadmap for recovery. The goal is to start with the lowest step, practice it repeatedly until it's less scary, and only then move up the ladder. You've done the hardest part, which is making the plan."}
                ]
            }
        ]
    }
}