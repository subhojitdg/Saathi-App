# saathi_app/core/clinical_assessment_agent.py
import logging
from typing import List, Dict, Optional
from datetime import datetime
from config import AssessmentType, PHQ9_QUESTIONS, GAD7_QUESTIONS, PSS_QUESTIONS
from core.tools import parse_assessment_response

logger = logging.getLogger(__name__)

class StructuredAssessment:
    """Implements a single, stateful validated clinical assessment tool."""
    
    def __init__(self, assessment_type: AssessmentType):
        self.type = assessment_type
        self.questions = self._get_questions()
        self.current_question_index = 0
        self.responses: List[int] = []
        self.total_score: int = 0
        self.severity: str | None = None
        self.completed: bool = False
        self.start_time: datetime = datetime.now()
        logger.info(f"📋 Started {assessment_type.value.upper()} assessment")

    def _get_questions(self) -> List[str]:
        if self.type == AssessmentType.PHQ9: return PHQ9_QUESTIONS
        if self.type == AssessmentType.GAD7: return GAD7_QUESTIONS
        if self.type == AssessmentType.PSS: return PSS_QUESTIONS
        return []

    def get_next_question(self) -> Optional[str]:
        if not self.completed and self.current_question_index < len(self.questions):
            q_num = self.current_question_index + 1
            q_total = len(self.questions)
            question_text = self.questions[self.current_question_index]
            return (f"**Question {q_num} of {q_total}**\n\n"
                    f"Over the last 2 weeks, how often have you been bothered by:\n"
                    f"**'{question_text}'**?\n\n"
                    "Please respond with a number:\n"
                    "- **0** = Not at all\n- **1** = Several days\n"
                    "- **2** = More than half the days\n- **3** = Nearly every day")
        return None

    def record_response(self, score: int):
        self.responses.append(score)
        self.total_score += score
        self.current_question_index += 1
        if self.current_question_index >= len(self.questions):
            self.completed = True
            self._calculate_severity()
            logger.info(f"✅ Assessment complete. Score: {self.total_score}, Severity: {self.severity}")

    def _calculate_severity(self):
        if self.type == AssessmentType.PHQ9:
            if self.total_score <= 4: self.severity = "minimal"
            elif self.total_score <= 9: self.severity = "mild"
            elif self.total_score <= 14: self.severity = "moderate"
            elif self.total_score <= 19: self.severity = "moderately_severe"
            else: self.severity = "severe"
        elif self.type == AssessmentType.GAD7:
            if self.total_score <= 4: self.severity = "minimal"
            elif self.total_score <= 9: self.severity = "mild"
            elif self.total_score <= 14: self.severity = "moderate"
            else: self.severity = "severe"
        else:
            self.severity = "unknown"

    def get_summary(self) -> Dict:
        interpretations = {
            "phq9": {
                "minimal": {"description": "Minimal or no depression symptoms.", "recommendation": "Monitor your mood and continue with self-care."},
                "mild": {"description": "Mild depression symptoms.", "recommendation": "Lifestyle changes, stress management, or talking to a friend may be helpful."},
                "moderate": {"description": "Moderate depression symptoms.", "recommendation": "It is recommended to consult with a doctor or mental health professional."},
                "moderately_severe": {"description": "Moderately severe depression symptoms.", "recommendation": "Professional help is strongly recommended. Please speak with a mental health provider."},
                "severe": {"description": "Severe depression symptoms.", "recommendation": "Immediate professional evaluation is highly recommended. Please contact a mental health professional or a crisis line today."},
            },
            "gad7": {
                "minimal": {"description": "Minimal anxiety.", "recommendation": "Continue your current self-care routines."},
                "mild": {"description": "Mild anxiety.", "recommendation": "Consider mindfulness, exercise, or other stress-reduction activities."},
                "moderate": {"description": "Moderate anxiety.", "recommendation": "Speaking with a therapist or counselor is recommended to learn coping strategies."},
                "severe": {"description": "Severe anxiety.", "recommendation": "It is strongly recommended to seek help from a mental health professional for evaluation and treatment."},
            }
        }
        return {
            "assessment_type": self.type.value,
            "total_score": self.total_score,
            "max_score": len(self.questions) * 3,
            "severity": self.severity,
            "interpretation": interpretations.get(self.type.value, {}).get(self.severity, {}),
            "completed": self.completed,
            "timestamp": datetime.now().isoformat()
        }

class ClinicalAssessmentAgent:
    """Manages the lifecycle of a clinical assessment session."""
    
    def __init__(self):
        self.active_assessment: Optional[StructuredAssessment] = None

    def start(self, assessment_type: AssessmentType) -> str:
        """Starts a new assessment and returns the first question."""
        self.active_assessment = StructuredAssessment(assessment_type)
        return self.active_assessment.get_next_question()

    def process_response(self, user_input: str) -> str:
        """Processes a user's response and returns the next question or completion status."""
        if not self.active_assessment:
            return "Error: No active assessment."
            
        score = parse_assessment_response(user_input)
        if score == -1:
            return f"I didn't quite understand. Please use a number from 0 to 3.\n\n{self.active_assessment.get_next_question()}"
        
        self.active_assessment.record_response(score)
        
        if self.active_assessment.completed:
            return "ASSESSMENT_COMPLETE"
        else:
            return self.active_assessment.get_next_question()

    def get_summary(self) -> Dict:
        """Returns the summary dictionary from the active assessment."""
        if self.active_assessment and self.active_assessment.completed:
            return self.active_assessment.get_summary()
        return {} # Return an empty dict if no completed assessment is active
    
    def determine_assessment_type(self, symptoms: List[str], hybrid_context: Dict) -> AssessmentType:
        """Intelligently determines the appropriate assessment based on symptoms and graph context."""
        anxiety_keywords = {"anxious", "worry", "panic", "fear", "nervous"}
        depression_keywords = {"sad", "depressed", "hopeless", "worthless", "interest", "empty"}
        
        symptom_text = " ".join(symptoms).lower()
        anxiety_score = sum(1 for kw in anxiety_keywords if kw in symptom_text)
        depression_score = sum(1 for kw in depression_keywords if kw in symptom_text)

        if hybrid_context.get('graph_context'):
            for context in hybrid_context['graph_context']:
                for disorder in context.get('disorders', []):
                    disorder_name = (disorder.get('name') or '').lower()
                    if 'anxiety' in disorder_name: anxiety_score += 2
                    if 'depression' in disorder_name: depression_score += 2
        
        logger.info(f"Assessment selection scores -> Anxiety: {anxiety_score}, Depression: {depression_score}")
        
        return AssessmentType.PHQ9 if depression_score > anxiety_score else AssessmentType.GAD7